# fake_news
This is my fake news detaction repository..
